angular.module('miApp', ['ngAnimate', 'ngMessages'])

.service('usuario', function(){





this.getName = function()
{

	return 'Usuario Correcto';
}




})


.controller('loginCtrl', function($scope, $http, $window, usuario) {
	$scope.ingresar = function() {
		
		var username = $scope.usuario;
		var password = $scope.pass;
		$http({
			url: 'codigo.php',
			method: 'POST',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded'
			},
			data: 'username='+username+'&password='+password
		}).then(function(response) {
			if(response.data.status == 'loggedin') {
			
		         alert('es el usuario correcto')
		         $window.location.href = 'bienvenida.html'
				
			} else {
				alert('Usuario o contraseña incorrectas');
				$window.location.href = 'inicio.html'
			}
		})
	}
})




.controller('miCtrl', function($scope, $filter, $http, $window, $log){


$scope.texto = 'Mis Empleados';



$scope.enunciado = $filter('uppercase')($scope.texto) 	

	$http({method:'post', url: 'empleados.json'}).then(function(respuesta){

$scope.empleados = respuesta.data
$log.warn(respuesta)

	}, function(error){

$window.location.href ='inicio.html'

	})



$scope.quitar = function(indice){

$scope.empleados.splice(indice,1)

}
	

$scope.comprobarBusqueda = function(){

if($scope.formularioBusqueda.$invalid){

$scope.errorBusqueda = true


}

else {$scope.errorBusqueda = false }


}


})


.controller('miFormu', function($scope){

$scope.sumar = function(){

$scope.empleados.push($scope.formu)
$scope.formu = {}

}




})


.controller('bienvenidaCtrl', function($scope, $window, usuario){
$scope.username = usuario.getName()
$scope.ir = function(){

$window.location.href = 'ejemplo.html'


}


})


.controller('miCoaching', function($scope){

$scope.coaching = function(){
var contador = 0;

angular.forEach($scope.empleados, function(empleado){

contador += empleado.coaching == true


})

return contador
}



})


.filter('maximo', function(){



return function(texto,dato){

if(texto.length > dato){

return texto.substring(0, dato) + "..."


}
   }
      })




